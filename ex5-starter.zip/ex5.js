const messages = [
  {
    type: "ERROR",
    text: "All your base are belong to us",
    icon: "browser-type-safari-md"
  },
  {
    type: "INFO",
    text: "This is not the message you were expecting",
    icon: "browser-type-chrome-md"
  },
  {
    type: "SUCCESS",
    text: "Your order has been delivered",
    icon: "browser-type-firefox-md"
  }
];

function pickMessage() {}

function addMessage() {}

function removeMessage() {}
